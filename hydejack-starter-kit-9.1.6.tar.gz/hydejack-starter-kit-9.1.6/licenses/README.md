# Licenses

## Open Source
* [Apache-2.0](./Apache-2.0.md)
* [GPL-3.0](./GPL-3.0.md)
* [MIT](./MIT.md)
* [W3C-20150513](./W3C-20150513.md)

## Custom
* [PRO](./PRO.md)
